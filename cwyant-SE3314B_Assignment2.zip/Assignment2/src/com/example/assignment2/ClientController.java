package com.example.assignment2;

//import java.io.IOException;
//import java.net.UnknownHostException;

import android.os.AsyncTask;
import android.util.Log;
import android.widget.EditText;
//import android.widget.Toast;
import android.widget.ToggleButton;

//This component should understand the RTSP message format and respond accordingly
public class ClientController {
	private MainClientView view;
	private RTSPModel rtsp;
	private RTPModel rtp;
	private String serverResponse;
	private VideoPlayback pb;
	private String videoSelection;
	
	public ClientController(MainClientView view){ //Default constructor, linking it to the view
		this.view = view;
		this.rtsp = new RTSPModel();
		this.rtp = new RTPModel();
	}
	
	public void RTSPSetup(){
		//create a setup message and pass it off the the RTSP model
		pb = new VideoPlayback();
		EditText video = (EditText)view.findViewById(R.id.editText1);
		videoSelection = video.getText().toString();
		serverResponse = rtsp.sendRTSPSetupCommand(new String[]{"SETUP rtsp://10.0.2.2:3000/"+videoSelection+" RTSP/1.0\nCSeq: ", "\nTransport: RTP/UDP; client_port= 25000\n\r"});
		if(serverResponse.equals("OK"))
			view.setupSuccessful();
		else{
			view.setErrorToast(serverResponse);
			view.teardownSuccessful(); //perform a teardown if we can't set up
			view.enableConnectionFields();
		}	
	}
	
	public void RTSPPlay(){
		//create RTSP play messages and sends them to the RTSP model
		serverResponse = rtsp.sendRTSPPlayPauseCommand(new String[]{"PLAY rtsp://10.0.2.2:3000/"+videoSelection+" RTSP/1.0\nCSeq: ","\nSession: ","\n\r"});
		Log.i("Server Response", serverResponse);
		if(!serverResponse.equals("OK"))
			view.setErrorToast("Unable to play video");
		//If we reach this point we know that the server is starting to send UDP datagrams, so we will need to set up a UDP socket and catch traffic
		rtp.setupPlayback("25000"); //we know that the port will always be 25000
		if(pb.getStatus() != AsyncTask.Status.RUNNING){ //check if the task is running in the background
			pb.execute();
		}
	}
	
	public void RTSPPause(){
		//create RTSP pause messages and sends them to the RTSP model
		serverResponse = rtsp.sendRTSPPlayPauseCommand(new String[]{"PAUSE rtsp://10.0.2.2:3000/"+videoSelection+" RTSP/1.0\nCSeq: ","\nSession: ","\n\r"});
		Log.i("Server Response", serverResponse);
		//pb.cancel(true); //cancel the asyc task that is catching UDP information
		if(!serverResponse.equals("OK"))
			view.setErrorToast("Video is unstopable!!");
	}
	
	public void RTSPTeardown(){
		//create RTSP teardown messages and send them to the RTSP model
		serverResponse = rtsp.sendRTSPTeardownCommand(new String[]{"TEARDOWN rtsp://10.0.2.2:3000/"+videoSelection+" RTSP/1.0\nCSeq: ","\nSession: ","\n\r"});
		Log.i("Server Response", serverResponse);
		if(serverResponse.equals("OK")){
			view.teardownSuccessful();
			view.enableConnectionFields();
		}
		else
			view.setErrorToast("Unable to teardown video");
	}
	
	public boolean connect(String ipAddress, String port){
		if(ipAddress.equals("") || port.equals(""))
			return false;
		return rtsp.connectToServer(ipAddress, port);
	
	}
	
	
	private class VideoPlayback extends AsyncTask<Void, byte[], Void>{
		private boolean errorThrown = false;
		@Override
		protected Void doInBackground(Void... arg0) {
			//This function is in charge of handling the UDP connection
			while(true){
				byte[] payload  = rtp.getPlaybackFrame(); //receive a frame, don't do anything with it for now
				publishProgress(payload); //update the view when information has been received
				if(payload == null){
					errorThrown = true;
					break;
				}
			}
			return null;
		}
		
		
		@Override
		protected void onPostExecute(Void result){
			if(errorThrown == true){
				view.setErrorToast("Video playback stream unavaliable");
			}
		}
		
		protected void onProgressUpdate(byte[]... payload){
			ToggleButton pauseButton = (ToggleButton)view.findViewById(R.id.pauseToggleButton);
			if(pauseButton.isChecked())
				return; //don't update the view if the pause button has been pressed
			view.setImageView(payload[0]);
		}
	}

}
