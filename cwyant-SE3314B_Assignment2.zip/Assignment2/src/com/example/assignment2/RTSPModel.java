package com.example.assignment2;
import android.annotation.TargetApi;
//import android.os.AsyncTask;
import android.os.Build;
import android.os.StrictMode;
import android.util.Log;
import java.io.*;
import java.net.*;

public class RTSPModel{
	private Socket rtspConnection = null;
	private PrintWriter out = null;
	private BufferedReader in = null;
	private String ipAddress;
	private String port;
	private String serverResponse;
	private String session;
	private int sequence = 1;
	private Thread worker;
	
	
	@TargetApi(Build.VERSION_CODES.GINGERBREAD)
	public RTSPModel(){ //Default constructor, sets up the TCP connection with the video server
		StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
		StrictMode.setThreadPolicy(policy); 
	}
	
	public boolean connectToServer(String ip, String port){
		this.ipAddress = ip;
		this.port = port;
		rtspConnection = new Socket();  //Create a new socket everytime the connec button is pressed
		worker = new Thread(new CreateTCPConnection());
		worker.start();
		return true;
	}
	
	public String sendRTSPSetupCommand(String[] command){
		try{
			if(!rtspConnection.isConnected()){
				return "The video player cannot connect to the server";
			}
			command[0]+=Integer.toString(sequence);
			serverResponse = "";
			out.println(command[0]+command[1]);
			out.flush();
		}catch(Exception e){
			
		}
		try {
			String tempRead;
			while(!(tempRead = in.readLine()).equals(null)){
				serverResponse += tempRead+"\n";
				String[] splitString = tempRead.split(":");
				if(splitString[0].equals("Session"))
					break;
				tempRead = null;
			}
		} catch (IOException e) {
		}
		sequence ++; //increment the sequence number for each request sent
		//next step is to parse
		try{
			String[] splitResponse = serverResponse.split(" ");
			session = splitResponse[4].split("\n")[0];
			return splitResponse[2].split("\n")[0];
		}catch(Exception e){
			return "Setup unsuccessful...the video probably never existed...";
		}
	}
	
	public String sendRTSPPlayPauseCommand(String[] command){
		command[0]+=Integer.toString(sequence);
		command[1]+= session;
		serverResponse = "";
		out.println(command[0]+command[1]+command[2]);
		out.flush();
		try {
			String tempRead;
			while(!(tempRead = in.readLine()).equals(null)){
				Log.i("Temp Read value",tempRead);
				serverResponse += tempRead+"\n";
				String[] splitString = tempRead.split(":");
				if(splitString[0].equals("Session"))
					break;
				tempRead = null;
			}
		} catch (IOException e) {
			//e.printStackTrace();
		}
		sequence ++; //increment the sequence number for each request sent
		//next step is to parse
		String[] splitResponse = serverResponse.split(" ");
		return splitResponse[2].split("\n")[0];
	}
	
	public String sendRTSPTeardownCommand(String[] command){
		command[0]+=Integer.toString(sequence);
		command[1]+= session;
		serverResponse = "";
		out.println(command[0]+command[1]+command[2]);
		out.flush();
		//this.execute();
		try {
			String tempRead;
			while(!(tempRead = in.readLine()).equals(null)){
				serverResponse += tempRead+"\n";
				String[] splitString = tempRead.split(":");
				if(splitString[0].equals("Session"))
					break;
				tempRead = null;
			}
		} catch (IOException e) {
		}
		sequence ++; //increment the sequence number for each request sent
		//next step is to parse
		String[] splitResponse = serverResponse.split(" ");
		
		//finally close the socket connections
		try {
			rtspConnection.close();
			rtspConnection = null;
		} catch (IOException e) {
		}
		out.close();
		try {
			in.close();
		} catch (IOException e) {//
			e.printStackTrace();
		}
		return splitResponse[2].split("\n")[0];
	}
	//a function that will set up the connection to the server
	private class CreateTCPConnection extends Thread{
		public void run() {
			// TODO Auto-generated method stub
			try{
				rtspConnection = new Socket(ipAddress,Integer.parseInt(port));
				out = new PrintWriter(rtspConnection.getOutputStream(), true);
				in = new BufferedReader(new InputStreamReader(rtspConnection.getInputStream()));
			}catch(UnknownHostException e){
			}catch (IOException e){
			}catch(Exception e){
			}
		}
	}
}
