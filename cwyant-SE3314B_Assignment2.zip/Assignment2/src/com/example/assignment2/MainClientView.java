package com.example.assignment2;

import android.os.Bundle;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
//import android.app.AlertDialog;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainClientView extends Activity{
	private ClientController controller;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main_client_view);
		controller = new ClientController(this);
		ToggleButton setup = (ToggleButton)findViewById(R.id.setupToggleButton);
		ToggleButton play = (ToggleButton)findViewById(R.id.playToggleButton);
		ToggleButton pause = (ToggleButton)findViewById(R.id.pauseToggleButton);
		ToggleButton teardown = (ToggleButton)findViewById(R.id.teardownToggleButton);
		setup.setEnabled(false);
		play.setEnabled(false);
		pause.setEnabled(false);
		teardown.setEnabled(false);
		
		//RadioGroup group = (RadioGroup)findViewById(R.id.radioGroup1);
		//group.check(R.id.radio2);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity_main_client_view, menu);
		return true;
	}
	
	public void setupTogglePressed(View v){
		//Ensure all other buttons have been deactivated
		ToggleButton playButton = (ToggleButton)findViewById(R.id.playToggleButton);
		ToggleButton pauseButton = (ToggleButton)findViewById(R.id.pauseToggleButton);
		playButton.setChecked(false);
		pauseButton.setChecked(false);
		//End of button deactivation
		
		//After the setup has complete, we don't want the button to stay pressed so disbale it
		ToggleButton setupButton = (ToggleButton)findViewById(R.id.setupToggleButton);
		setupButton.setChecked(false);
		controller.RTSPSetup();
	}
	
	public void playTogglePressed(View v){
		//Ensure all other buttons have been deactivated
		ToggleButton pauseButton = (ToggleButton)findViewById(R.id.pauseToggleButton);
		pauseButton.setChecked(false);
		//End of button deactivation
		controller.RTSPPlay();
	}
	
	public void pauseTogglePressed(View v){
		ToggleButton playButton = (ToggleButton)findViewById(R.id.playToggleButton);
		playButton.setChecked(false);
		controller.RTSPPause();
	}
	
	public void teardownTogglePressed(View v){
		//Ensure all other buttons have been deactivated
		ToggleButton playButton = (ToggleButton)findViewById(R.id.playToggleButton);
		ToggleButton pauseButton = (ToggleButton)findViewById(R.id.pauseToggleButton);
		playButton.setChecked(false);
		pauseButton.setChecked(false);
		//End of button deactivation
		
		//after the teardown has finished, unselect the teardown button
		ToggleButton teardownButton = (ToggleButton)findViewById(R.id.teardownToggleButton);
		teardownButton.setChecked(false);
		controller.RTSPTeardown();
	}
	
	public void connectButtonClick(View v){
		EditText ip = (EditText)findViewById(R.id.ipInput);
		EditText port = (EditText)findViewById(R.id.portInput);
		EditText video = (EditText)findViewById(R.id.editText1);
		Button connectButton =  (Button)findViewById(R.id.connectButton);
		if(controller.connect(ip.getText().toString(), port.getText().toString())){
			//connection was successful
			//Toast toast = Toast.makeText(getApplicationContext(), "Connection Established!", Toast.LENGTH_SHORT);
			//toast.show();
			ip.setEnabled(false);
			port.setEnabled(false);
			video.setEnabled(false);
			connectButton.setEnabled(false);
			ToggleButton setup = (ToggleButton)findViewById(R.id.setupToggleButton);
			setup.setEnabled(true);
		}else{
			Toast toast = Toast.makeText(getApplicationContext(), "Unable to connect to the server, verify ip and port numbers and make sure the server is running", Toast.LENGTH_LONG);
			toast.show();
		}
	}
	
	public void setupSuccessful(){
		ToggleButton setup = (ToggleButton)findViewById(R.id.setupToggleButton);
		ToggleButton play = (ToggleButton)findViewById(R.id.playToggleButton);
		ToggleButton pause = (ToggleButton)findViewById(R.id.pauseToggleButton);
		ToggleButton teardown = (ToggleButton)findViewById(R.id.teardownToggleButton);
		setup.setEnabled(false);
		play.setEnabled(true);
		pause.setEnabled(true);
		teardown.setEnabled(true);
	}
	
	public void teardownSuccessful(){
		ToggleButton setup = (ToggleButton)findViewById(R.id.setupToggleButton);
		ToggleButton play = (ToggleButton)findViewById(R.id.playToggleButton);
		ToggleButton pause = (ToggleButton)findViewById(R.id.pauseToggleButton);
		ToggleButton teardown = (ToggleButton)findViewById(R.id.teardownToggleButton);
		setup.setEnabled(true);
		play.setEnabled(false);
		pause.setEnabled(false);
		teardown.setEnabled(false);
	}
	
	public void enableConnectionFields(){
		EditText ip = (EditText)findViewById(R.id.ipInput);
		EditText port = (EditText)findViewById(R.id.portInput);
		EditText video = (EditText)findViewById(R.id.editText1);
		Button connectButton =  (Button)findViewById(R.id.connectButton);
		ip.setEnabled(true);
		port.setEnabled(true);
		video.setEnabled(true);
		connectButton.setEnabled(true);
		
		//Disable the RTSP command buttons
		ToggleButton setup = (ToggleButton)findViewById(R.id.setupToggleButton);
		ToggleButton play = (ToggleButton)findViewById(R.id.playToggleButton);
		ToggleButton pause = (ToggleButton)findViewById(R.id.pauseToggleButton);
		ToggleButton teardown = (ToggleButton)findViewById(R.id.teardownToggleButton);
		setup.setEnabled(false);
		play.setEnabled(false);
		pause.setEnabled(false);
		teardown.setEnabled(false);
	}
	public void setErrorToast(String toastText){
		Toast toast = Toast.makeText(getApplicationContext(), toastText, Toast.LENGTH_SHORT);
		toast.show();
	}
	
	//sets the image view based on the byte data sent
	public void setImageView(byte[] data){
		if(data != null){
			Bitmap bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
			ImageView image = (ImageView)findViewById(R.id.playbackVideo);
			image.setImageBitmap(bitmap);
		}
	}
}
