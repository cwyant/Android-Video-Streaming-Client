package com.example.assignment2;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketTimeoutException;

import android.util.Log;

public class RTPModel {
	private DatagramSocket socket;
	private DatagramPacket packet;
	private int port;
	//private byte[] buffer = new byte[2048]; //make sure we have lots of buffer space
	
	public void setupPlayback(String port){
		this.port = Integer.parseInt(port);
		try{
			socket = new DatagramSocket(this.port);
			socket.setSendBufferSize(64000);
			socket.setReceiveBufferSize(64000);
			Log.i("maximum packet size",Integer.toString(socket.getReceiveBufferSize()));
		}catch(Exception e){
			
		}
	}
	
	public byte[] getPlaybackFrame(){
		try {
			packet = new DatagramPacket(new byte[64000],64000);
			socket.receive(packet);
			Log.i("Packet caught","Incomming packet");
			//convert the message into a string and log the result
			//String msg = new String(buffer,0,packet.getLength());
			//Log.i("The packet content is",msg);
			RTPPacket rtpPacket = new RTPPacket(packet);
			return rtpPacket.getPayload();
			
		} catch(SocketTimeoutException e){
			Log.i("Socket Timeout", "The socket has timed out and not received any data");
		}catch (IOException e) {
			Log.i("No Information received",e.getCause().getMessage());
		}
		return null;
	}
}
