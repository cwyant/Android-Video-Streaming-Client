package com.example.assignment2;
import android.annotation.TargetApi;
import android.os.Build;
import java.net.DatagramPacket;
import java.util.Arrays;

//this class will be in charge of reading the packet headers and analysing the information 
public class RTPPacket{
	private DatagramPacket packet;
	
	public RTPPacket(DatagramPacket packet){
		this.packet = packet;
	}
	
	@TargetApi(Build.VERSION_CODES.GINGERBREAD)
	public byte[] getPayload(){
		byte[] packetData = Arrays.copyOf(packet.getData(), packet.getLength());
		byte[] payload  = new byte[packetData.length - 12];
		for(int i=0; i<payload.length; i++){
			payload[i] = packetData[i+12];
		}
		return payload;
	}
	
}
